# prog3
helper files for the intro cg class's third programming assignment
Parts 1-3 completed as per specification.
Part 4 completed with model by model sorting.
